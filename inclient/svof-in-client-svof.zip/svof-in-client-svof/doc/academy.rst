rule #1: this is just a game

serpents
quick enough - can illusion twice per dstab

does nothing - hypnoing you then, watch our for burst offensive with a snap

apostates
cure impatience before slickness with them

watch out for blackout

alchemists
don't get caught with low mana and bleeding, with a sanguine humour it'll keep increasing every tic - a death even if you manage to get away (unless you can crystal)


retardation
plan every move
pre-attack
don't be afraid to reset (tumble out, takes time, cure up while tumbling)

newbies start:
use gags, use subs, use highlights
