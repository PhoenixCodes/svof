Svof Rune Identifier
======================
No commands necessary! Just look in a room, on a person, or probe a totem, and it'll tell you what the runes are called and their effect.
